﻿namespace YAZLAB2
{
    public class SharedClass
    {
        public static int id {  get; set; }
        public static string rol { get; set; }
        public static bool loggedin { get;set; }
    }

}
